<?php
require_once(__DIR__."/../bootstrap.php");

$seeder = new atd\Seeder();
$seeder->seed("Adedeji Stephen", "Nov");