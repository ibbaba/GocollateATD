<?php
//Class for Managing Employees' Action
//Add, Query etc

namespace atd;

use atd;

class Employee {
    use atd\Database\DBConnect;
    private $dbh = false;

    public function __construct(){
        try{
            $this->dbh = $this->dbConnect();
        } catch(Exception $e){
            echo "Failed to Establish Connection";
            die(0);
        }
    }

    public function addEmployee($firstname, $othername, $role){
        $stmt = $this->dbh->prepare("INSERT INTO employee(firstname, othername, role) VALUES (?, ?, ?)");
        if($stmt->execute(array($firstname, $othername, $role))){
            return true;
        } else{
            return false;
        }
    }

    public function getAllEmployee(){
        $stmt = $this->dbh->prepare("SELECT * FROM employee");
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    }

    private function isCheckedInToday($fullname){
        $stmt = $this->dbh->prepare("SELECT * FROM attendance WHERE fullname = ? AND month = ? AND day = ?");
        $day = Date('j');
        $month = Date('M');

        $stmt->execute(array($fullname, $month, $day));
        $row = $stmt->fetchAll();
        if($row){
            return true;
        } else {
            return false;
        }
    }

    public function checkIn($fullname, $status, $status_exp){
        $stmt = $this->dbh->prepare("INSERT INTO attendance(fullname, `day`, `month`, `year`, `time`,status, status_exp) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $day = Date('j');
        $month = Date('M');
        $year = Date('Y');
        $time = Date('G:i');

        if(!$this->isCheckedInToday($fullname)){
            $stmt->execute(array($fullname, $day, $month, $year, $time, $status, $status_exp));
            return true;
        } else {
            return false;
        }

    }

}