<?php
require_once(__DIR__."/bootstrap.php");
//start New Session
$session = new atd\Session();
//Is user signed in already?
if($session->get('auth'))
    header("Location: /home");

//Grab LogIn Error Message if present
if($session->get("errorMsg")){
    $message = $session->get("errorMsg");
    $session->delete("errorMsg");
}

?>

<html>
<head>
    <meta charset="UTF-8">
    <title>Gocollate Attendance System | Log In</title>
    <link rel="stylesheet" href="css/login.css"/>
    <link rel="stylesheet" href="external/fontawesome/css/font-awesome.min.css"/>
</head>
<body>
<div id="topbar">
    <i class="fa fa-database"></i> <h5 class="fg-asphalt">goCollate Attendance System</h5>
</div>

<div id="box-login">
<div class="row">
    <br>
    <?
        if(isset($message)){
            echo "<div class='error'><i class='fa fa-info-circle'></i><p>$message</p></div>";
        }
    ?>
    <form method="post" action="verify.php">
        <div class="small-12 column relative">
            <i class="fa fa-user ico"></i>
            <input type="text" class="login-field" placeholder="Username" name="username">
        </div>
            <hr>
        <div class="small-12 column relative">
            <i class="fa fa-lock ico"></i>
            <input type="password" class="login-field" placeholder="Password" name="password">
        </div>

        <div class="small-12 column pad-sm relative">
            <button type="submit" class="block button-primary">Log In <i class="fa fa-sign-in"></i> </button>
        </div>
    </form>
</div>
</div>
</body>
</html>
