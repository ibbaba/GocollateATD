//Angular Javascript

var app = angular.module('atd', []);

app.controller("mainController", ["$scope", "$http", "$log", "$httpParamSerializer", function($scope, $http, $log, $httpParamSerializer){
    $scope.firstname = '';
    $scope.othername = '';
    $scope.role = '';
    $scope.addEmployee = function(){
        $http({
            url: 'ajax/addEmployee.php',
            method: "POST",
            headers : {'Content-Type' : 'application/x-www-form-urlencoded'},
            data: $httpParamSerializer({firstname: $scope.firstname, othername: $scope.othername, role: $scope.role})
        }).then(function(data){
            $log.info(data.data);
            $scope.firstname = "";
            $scope.othername = "";
            $scope.role = "";
            document.location("/");
        })
    }

    $scope.present = function(fullname){
        $log.info(fullname);
    }
}]);


//jQuery Code Segment (Mainly for Checking In Employee and Maniplating the DOM
(function(){


    $('button').click(function(){
        alert("Hello Button");
    })
})();

$(function(){
    $('.checkin').on('click', function(){
        //When Check Element Is been Clicked:
        var employeeName = $(this).attr('data-name');
        var chechInType = $(this).attr('data-check');
        var type = $(this).attr('data-exp');
        var self = this;

        //Make an AJAX Call:
        $.ajax({
            url: 'ajax/checkin.php',
            type: 'POST',
            data: {fullname: employeeName, check: chechInType, exp: type},
            success: function(data){
                alert(data.message);
                //$(this).parent().parent().fadeTo(3000);
                $(self).parent().parent().fadeOut(1500);
            },

            error: function(data){
                console.log(data);
            }
        })
    });
})