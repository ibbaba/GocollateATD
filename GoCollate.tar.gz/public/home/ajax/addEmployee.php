<?php
//Adds New Employee to Database by Utilizing Employee Class
require_once(__DIR__."/../../bootstrap.php");
$session = new atd\Session();
//Check if User IsLoggedIn?
if(!atd\Auth\Auth::isUserLoggedIn())
    header("location: /../../");

header("Content-Type: application/json");

if(isset($_POST['firstname']) && isset($_POST['othername']) && isset($_POST['role'])
    && !empty($_POST['othername']) && !empty($_POST['firstname']) && !empty($_POST['role'])){

    $employee = new atd\Employee();

    if($employee->addEmployee($_POST['firstname'], $_POST['othername'], $_POST['role'])){
        echo json_encode(["status" => "Success", "message" => "Employee has been successfully added"]);
    } else {
        echo json_encode(["status" => "Failed", "message" => "Failed to add Employee first-if"]);
    }
} else {
    echo json_encode(["status" => "Failed", "message" => "Failed to add Employee second-if"]);
}
