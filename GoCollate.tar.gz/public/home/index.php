<?php
require_once(__DIR__."/../bootstrap.php");

//Start New session class
$session = new atd\Session();

//Check to see if user is Logged In
if(!atd\Auth\Auth::isUserLoggedIn())
    header("Location: /");

?>
<html ng-app="atd">
<head>
    <meta charset="UTF-8">
    <title>GoCollate Attendance System | Dashboard</title>
    <link rel="stylesheet" href="../css/app.css"/>
    <link rel="stylesheet" href="../external/fontawesome/css/font-awesome.min.css"/>
    <script src="../external/jquery/jquery-3.0.0.min.js"></script>
    <script src="../external/angular/angular.min.js"></script>
    <script src="../scripts/app.js"></script>
</head>
<body>
<div class="full-width row" id="menu">
    <div class="small-12 medium-12 column no-pad">
        <!--Top-Menu-Bar-->
        <div class="top-bar" id="menu-bar">

            <div class="top-bar-left">
                <ul class="menu">
                    <li class="menu-text"><i class="fa fa-database ico-md"></i> </li>
                </ul>
            </div>

            <div class="top-bar-right">
                <ul class="menu" style="padding-top: 5px;">
                    <li><a href="#"><i class="fa fa-home ico-md"></i> Home</a> </li>
                    <li><a href="logout.php"><i class="fa fa-sign-out ico-md"></i> Logout</a> </li>
                </ul>
            </div>
            <div class="clearfix"></div>
        </div><!--top-bar ends-->
    </div>
</div><!--header Container Ends-->

<!--Content Body Here------>
<div class="full-width row" ng-controller="mainController">
    <div class="small-3 column">
        <br><br>
        <div class="row">
            <div class="small-12 pad-sm bg-primary rad-sm">
                <h5>New Employee</h5>
                <hr class="primary-line">
                <form>
                    <div class="row pad-sm">
                        <label class="bold">Firstname</label>
                        <div class="small-12 column">
                            <input type="text" name="firstname" placeholder="Firstname" class="field" ng-model="firstname">
                        </div>
                    </div>

                    <div class="row pad-sm">
                        <label class="bold">Othername</label>
                        <div class="small-12 column">
                            <input type="text" name="othername" placeholder="Othernames" class="field" ng-model="othername">
                        </div>
                    </div>

                    <div class="row pad-sm">
                        <label class="bold">Employee's Role</label>
                        <div class="small-12 column">
                            <input type="text" name="role" placeholder="Role" class="field" ng-model="role">
                        </div>
                    </div>

                    <div class="row pad-sm">
                        <div class="small-12 column">
                            <button type="button" ng-click="addEmployee()" class="block button-secondary">Add Employee <i class="fa fa-plus
                            "></i> </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!--employees' list box-->
    <div class="small-9 column">
        <div class="row pad-sm">
            <div class="small-5 small-offset-7 column">
                <div class="row">
                    <div class="small-4 column text-center helper">
                      <span><i class="fa fa-check ico-md" style="color: #008200"></i> <h6>Present</h6></span>
                    </div>
                    <div class="small-4 column text-center helper">
                        <span><i class="fa fa-times ico-md" style="color: red"></i> <h6>Absent</h6></span>
                    </div>
                    <div class="small-4 column text-center helper">
                        <span><i class="fa fa-minus ico-md" style="color: #15405d"></i> <h6>On Leave</h6></span>
                    </div>
                </div>
            </div>
        </div>

        <div class="row box-shadow-all">
            <div class="small-12 column bg-primary"><h5>Attendance Check-In for Employees</h5></div>
            <br><br>

            <div class="small-12 column">
                <table>
                    <thead>
                    <tr><td>S/N</td>
                        <td>FirstName</td>
                        <td>Other Name</td>
                        <td>Role</td>
                        <td>Action</td></tr>
                    </thead>

                    <tbody>

                    <?php
                        $employee_list = new atd\Employee();
                        $rows = $employee_list->getAllEmployee();
                        $sn = 1;
                        foreach($rows as $row){
                            $fullname = $row['firstname']. " ". $row['othername'];
                            $encoded_name = urlencode($fullname);

                            echo "<tr class='hello'><td>$sn</td>";
                            echo "<td>".$row['firstname'] ."</td>";
                            echo "<td>".$row['othername'] ."</td>";
                            echo "<td>".$row['role'] ."</td>";
                            echo '<td>';
                            echo "<button data-name='$fullname' data-exp='present' data-check='1' class='checkin' style='color: #008200'><i class='fa fa-check'></i> </button>";
                            echo "<button data-name='$fullname' data-exp='absent' data-check='0' class='checkin' style='color: red'><i class='fa fa-times'></i> </button>";
                            echo "<button data-name='$fullname' data-exp='onLeave' data-check='0' class='checkin' style='color: #15405d'><i class='fa fa-minus'></i> </button>";
                            echo "<a href='statistic.php?name=$encoded_name' type='button'><i class='fa fa-eye ico-md'></i> ";

                            echo '</td></tr>';
                            $sn = $sn + 1;
                        }
                    ?>

                    </tbody>
                </table>
            </div>
        </div>

    </div>
</div>
</body>
</html>