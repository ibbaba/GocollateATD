<?php
/*
 * Bootstraps Autoloading of Classes by Calling
 * Composer Autoload File.
 *
 * */

require_once __DIR__ . "/../vendor/autoload.php";