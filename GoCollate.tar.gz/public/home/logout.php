<?php
require_once(__DIR__."/../bootstrap.php");

//Start New session
$session = new atd\Session();

if(!atd\Auth\Auth::isUserLoggedIn())
    header("Location: /");

//Unset Session and Redirect
$session->delete('auth');
header("Location: /");