<?php
/**
 * Created by PhpStorm.
 * User: root
 * Date: 12/13/16
 * Time: 4:57 PM
 */

namespace atd;
use atd;

class Seeder {
    use atd\Database\DBConnect;

    private $dbh;

    public function __construct(){
        $this->dbh = $this->dbConnect();
    }

    public function seed($fullname, $month){
        $stmt = $this->dbh->prepare("INSERT INTO attendance(fullname, `day`, `month`, `year`, `time`,status, status_exp) VALUES (?,?,?,?,?,?,?)");

        $year = '2016';
        $time = Date("G:i");
        $status = 1;
        $status_exp = 'present';

        $i = 0;
        while($i < 30){
            $stmt->execute(array($fullname, $i, $month, $year, $time, $status, $status_exp));
            $i++;
        }
        echo "DOne";
    }
}