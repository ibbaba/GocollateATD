<html xmlns="http://www.w3.org/1999/html">
<head>
    <meta charset="UTF-8">
    <title>GoCollate Attendance System | About</title>
    <link rel="stylesheet" href="../css/app.css"/>
    <link rel="stylesheet" href="../external/fontawesome/css/font-awesome.min.css"/>
    <style>
        body{
            background-color: #ECF0F1;
        }
        #container{
            width: 600px;
            height: 400px;
            position: absolute;
            top: 0; bottom: 0; right: 0; left: 0;
            margin: auto;
        }
        img{
            width: 250px; height: 250px;
            border-radius: 50%;

        }
    </style>
</head>
<body>
<div id="container">
    <div class="row">
        <div class="small-centered large-centered medium-centered small-7 text-center column">
            <img src="../images/owner.jpg" alt="Ibrahim Pic">
        </div>
    </div>
    <br>
    <div class="row">
        <div class="small-centered large-centered medium-centered small-6 text-center column">
            <h4 class="fg-asphalt"><b>Ibrahim Oladokun</b></h4>
            <h6 class="fg-asphalt"><b>120805115</b></h6>
            <b>Depatment of Computer Science, Univeristy of Lagos, Lagos.</b>
            <br><br>
            <a href="index.php" class="button-primary btn-lg block"><i class="fa fa-home" style="font-size: 1.5em;"></i> Return Home</a>
        </div>
    </div>
</div>
</body>
</html>