<?php
namespace atd\Database;
/*
 * A trait that instantiate Connection to database
 * Only returns a connection Handler by Reference
 *
 *
 * */

trait DBConnect  {

    /*
     * Make Connection to DB
     * @param, null
     * @return new PDO Object by reference
     * */

    public function dbConnect(){
        $dbh = new \PDO("mysql:host=localhost;dbname=gocollate_atd", "atd", "gocollate");
        //sets ErrorMode to Exception
        $dbh->setAttribute(\PDO::ATTR_ERRMODE, \PDO::ERRMODE_EXCEPTION);

        return $dbh;

    }
}