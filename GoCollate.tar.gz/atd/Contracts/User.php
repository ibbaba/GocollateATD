<?php
/*
 * Specifies The User(Mod and Admin) Class Contracts
 * Interfaces.
 *
 * Adedeji Stephen (6th Nov, 2016) Edulus
 *
 * */

namespace atd\Contracts;


interface User{
    /*
     * @param [array] of data as specificed in the Database
     * @return [boolean] True if created, false otherwise
     *
     * */
    public function create(array $data);

    /*
     * @param [Int] Probe User's ID
     * @return [array] Of User's Data
     *
     * */
    public function getById($id);

    /*
     * Returns object of all Users' Data In the Database
     * */
    public function getAll();

    /*
     * @param [array] of user's data as in the Database
     * @return [boolean] True if updated, false otherwise
     *
     * */
    public function update(array $data);

    /*
     * @param [Int] of user to be lockdown
     *
     * @return [boolean] True if user lockdown, false otherwise
     * */
    public function lockdown($id);

    /*
     * @param [Int] user to ID to activate
     * @return [boolean] True if activated, false otherwise
     *
     * */
    public function activate($id);
}