<?php
require_once(__DIR__."/../bootstrap.php");

//Start New session class
$session = new atd\Session();

//Check to see if user is Logged In
if(!atd\Auth\Auth::isUserLoggedIn())
    header("Location: ../");

//Check If Query Isset
if(!$_GET['name']){
    header("Location: /");
    die();
}
$fullname = $_GET['name'];

?>

<html>
    <head>
        <meta charset="UTF-8">
        <title>GoCollate Attendance System | Employee Statistic</title>
        <link rel="stylesheet" href="../css/app.css"/>
        <link rel="stylesheet" href="../external/fontawesome/css/font-awesome.min.css"/>
        <script src="../external/jquery/jquery-3.0.0.min.js"></script>
        <script src="../external/Chart.bundle.min.js"></script>
        <script src="../scripts/app.js"></script>
    </head>
<body>
<!--Header-->
<div class="full-width row" id="menu">
    <div class="small-12 medium-12 column no-pad">
        <!--Top-Menu-Bar-->
        <div class="top-bar" id="menu-bar">

            <div class="top-bar-left">
                <ul class="menu">
                    <li class="menu-text"><i class="fa fa-database ico-md"></i> </li>
                </ul>
            </div>

            <div class="top-bar-right">
                <ul class="menu" style="padding-top: 5px;">
                    <li><a href="index.php"><i class="fa fa-home ico-md"></i> Home</a> </li>
                    <li><a href="logout.php"><i class="fa fa-sign-out ico-md"></i> Logout</a> </li>
                </ul>
            </div>
            <div class="clearfix"></div>
        </div><!--top-bar ends-->
    </div>
</div><!--header Container Ends-->
<br><br>
<h4 class="fg-asphalt">Aggregate Attendance Cumulative Chart</h4>
<hr>
<!--Statistics Bar [Line Graph]-->
<div class="row">
        <canvas id="stat" width="800" height="400" align="center" style="margin: 0 auto;"></canvas>
</div>
<?php
$graph = new \atd\Statistic();
$g_month = $graph->getMonth($_GET['name']);
$m_jx = [];
$sum_m = [];

foreach($g_month as $month){
    array_push($m_jx, $month['month']);
    $day = $graph->getDay($_GET['name'], $month['month']);
    $count = 0;
    foreach($day as $record){
        $count = $count + $record['status'];
    }
    array_push($sum_m, $count);
}

echo "<script> var months = [";
foreach($m_jx as $js){
    echo "'$js',";
}
echo "];";
echo "console.log(months); var aggr =[";

foreach($sum_m as $js){
    echo "'$js',";
}
echo "];";
echo "console.log(aggr);</script>";
?>
<script>

    var barData = {
        labels: months,
        datasets: [
            {
                label: '2010 customers #',
                fillColor: '#382765',
                data: aggr
            }
        ]
    };

    var context = document.getElementById('stat').getContext('2d');
    var clientsChart = new Chart(context).Bar(barData);

</script>
<br><br>
<!--EMployee Details Grid-->
<div class="row full-width">
    <div class="small-offset-2 small-2 float-right">
        <div class="row">
            <div class="small-12 bg-primary">
                <h5><b>Attendance summery</b></h5>
            </div>
        </div>
        <div class="row">
            <div class="small-12">
                <h6 class="fg-asphalt">Name: <b><?php echo $fullname ?></b></h6>
            </div>
        </div>

        <div class="row">
            <div class="small-12">
                <h6 class="fg-asphalt">goCollate Atd System Summery</h6>
            </div>
        </div>
    </div>
</div>




<!--Statistic Details-->
<div class="row margin-bottom-lg full-width">
    <div class="small-12 column bg-secondary"><h4>Attendance Details</h4></div>
</div>
<?php
$stat = new \atd\Statistic();
$month = $stat->getMonth($_GET['name']);
foreach($month as $present){
    $days = $stat->getDay($_GET['name'], $present['month']);
    echo "<div class='row box-shadow-all pad-md'><div class='small-offset-1 small-11 column'><h4 class='fg-asphalt'><b>".$present['month'].", ". Date("Y") ."</b></h4>";

    echo "<div class='row'><div class='small-12 columns'>";
    foreach($days as $day){
        echo "<div class='statdiv'>".$day['day']."<br>";
        if($day['status_exp'] == 'present'){
            echo "<b>PST</b>";
        } elseif($day['status_exp'] == 'absent') {
            echo "<b>ABS</b>";
        } else{
            echo "<b>ONL</b>";
        }
        echo "</div>";
    }

    echo "</div></div>";

    echo "</div></div><br><br>";
}
?>
</body>
</html>