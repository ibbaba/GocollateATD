<?php
/*
 * Interface(Contract Class) for Auth Class in atd
 * Namespace. Refer Back to this contract if, and before
 * Making changes to atd\Auth\Auth()
 *
 * Adedeji Stephen [Pythonleet] (27th of Oct, 2016) Edulus
 *
 *
 * */
namespace atd\Contracts\Auth;


interface Auth{
    /*
     * Check to see if User is Present in Database
     * @param [null] Access username from class
     *
     * @return [string] the found user salted Password
     *
     * */
    function isUserValid();

    /*
     * Validate if found user's supplied password matches
     * That was Submitted
     *
     * @param [string] the return salted Password from
     * $this->isUserValid()
     *
     * @return [boolean] return true if yes, false otherwise
     *
     * */

    function isPasswordValid($password);

    /*
     * A Getter Class to be called after Auth is sucessfull
     * Gets Information to be Logged by infoSetter()
     *
     * @param [null] takes nothing
     * @return [array] An array for infoSetter()
     *
     * */
    function infoGetter();

    /*
     * A setter Class to set all Necessary Information after
     * Validated by Using the Class Session
     *
     * @param [null] Will itself get data from infoGetter
     *
     * @return [null]
     *
     * */
    function infoSetter();

    /*
     * Runs the Whole Validation Process by Calling all Method Needed
     * @param [null] accepts all parameter from instantaited class
     *
     * @return [boolean] Performs setting Validated User in Session
     *
     * */


    function validate();

    /*
     * Unsets and Log LoggedIn Users Out
     *
     *
    function logOut();
    */
}