<?php
/*
 * The main Authenctication Class to be extends by the
 * Auth Class in edulus namespace where it is actually
 * Bootstrapped.
 *
 * Adedeji Stephen [PythonLeet] (28th Oct, 2016) Edulus
 *
 * */

namespace atd\Auth;

use atd;


class Auth implements atd\Contracts\Auth\Auth {
    use atd\Database\DBConnect;


    protected $username, $password;
    protected $dbh; //Database connection Handler
    public $session;

    public function __construct($username, $password){
        $this->username = $username;
        $this->password = $password;
        $this->session = new atd\Session();
        try {
            $this->dbh = $this->dbConnect();
        } catch(\Exception $e){
            die("Cannot Establish a secure Connection");
        }
    }

    public function isUserValid(){
        //Method Verifies if the Username supplied
        //Exists in the Database.

        $stmt = $this->dbh->prepare("SELECT password FROM admins WHERE username = ?");

        if($stmt->execute(array($this->username))){
            if($row = $stmt->fetch(\PDO::FETCH_OBJ)){
                return $row->password;
            }
            else {
                return false;
            }
        } else {
            return false;
        }



    }

    public function isPasswordValid($password){
        //Method Check to see if Supplied Username
        //Hash Matches the Supplied Password.

        if(password_verify($this->password, $password)){
            return true;
        } else {
            return false;
        }

    }

    public function infoGetter(){
        //Method will be called by infoSetter.
        //Not to be Explicitly Called.

        $stmt = $this->dbh->prepare("SELECT username, fullname FROM admins WHERE username = ?");
        $stmt->execute(array($this->username));
        $row = $stmt->fetch(\PDO::FETCH_OBJ);
        $info = array(
            $row->username,
            $row->fullname
        );

        return $info;

    }

    public function infoSetter(){

        $data = $this->infoGetter();

        //Flash Information into Session

        $this->session->set('username', $data[0]);
        $this->session->set('fullname', $data[1]);
        $this->session->set('auth', bin2hex(openssl_random_pseudo_bytes(6)));


    }

    public function validate(){
        if($key = $this->isUserValid()){
            //Proceed if User is Found, (getting password as $key)

            if($this->isPasswordValid($key)){
                //If Password matched user supplied, call infoSetter
                $this->infoSetter($this->infoGetter());
                return true;

            } else {
                return false;

            }
        } else {
            return false;
        }
    }

    static function logOut(){
        if(Auth::isUserLoggedIn()){
            unset($_SESSION['auth']);
        }

    }

    static function isUserLoggedIn(){
        //Returns [boolean] Depending if $_SESSION['auth'] is set

        if(isset($_SESSION['auth']) && $_SESSION['auth']){
            return true;
        } else {
            return false;
        }
    }

}