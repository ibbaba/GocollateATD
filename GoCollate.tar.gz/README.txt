================================================================================================================
1. Create Database User with username 'atd' and Password 'goCollate' or Change it in the atd/Database/DBCOnnect.php
================================================================================================================
2. Create a Database with name 'gocollate_atd' OR change it in the atd/Database/DBConnect.php
================================================================================================================
3. In your VirtualHost configuration, Point the Document public folder to '/public' directory. That's the view
================================================================================================================
4. Login with username 'ibrahim' and password '12345'
=================================================================================================================
5. You can clear the database with the populated data and re-populate yours with the /atd/Seeder.php. Just
Re-implement it
=================================================================================================================
6. Run
=================================================================================================================
