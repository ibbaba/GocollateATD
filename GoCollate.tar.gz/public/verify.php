<?php
/*
 * Process Admins and  Moderator's Authentication
 * Processes. Using Auth Class
 *
 * */
require_once(__DIR__."/bootstrap.php");

//Please start a session please?
$session = new atd\Session();

//Redirect If Already Logged In
if(atd\Auth\Auth::isUserLoggedIn())
    header("Location: home/");

//Redirect if CSRF does not match.
//if(!isset($_POST['csrf']) && !atd\Util\CSRF::csrfVerify($_POST['csrf']))
//    header('Location: index.php');

//We assume 'csrf' is present and Matched, so unset it
//$session->delete('csrf');

//Okay, let's Check if Username and password is present in $_POST
//If so, set variable of Username and Password, else, redirect with Msg
if(isset($_POST['username']) && !empty($_POST['username']) &&
    isset($_POST['password']) && !empty($_POST['password'])){

    $username = $_POST['username'];
    $password = $_POST['password'];
} else {
    header("Location: /");
}

//Okay, let's Authenticate. Starts Auth Class?
$auth = new atd\Auth\Auth($username, $password);
if($auth->validate()){
    header("Location: home/");
} else {
    $session->set('errorMsg', "Username or Password is Incorrect.");
    header("Location: /");

}