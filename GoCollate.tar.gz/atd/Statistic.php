<?php
//Class that populate Employee Statistic
//In Query.
namespace atd;
use atd;


class Statistic{
    use atd\Database\DBConnect;

    private $dbh;
    public function __construct(){
        try{
            $this->dbh = $this->dbConnect();
        } catch(\Exception $e){
            die("Could not Establish Database Connection");
        }
    }


    public function getMonth($fullname){
        $stmt = $this->dbh->prepare("SELECT month FROM attendance WHERE fullname = ? GROUP BY month");
        $stmt->execute(array($fullname));
        if($row = $stmt->fetchAll()){
            return $row;
        } else {
            return false;
        }
    }

    public function getDay($fullname, $month){
        $stmt = $this->dbh->prepare("SELECT `day`, status, status_exp FROM attendance WHERE fullname = ? AND `month` = ? ORDER BY 'day'");
        $stmt->execute(array($fullname, $month));
        if($row = $stmt->fetchAll()){
            return $row;
        } else{
            return false;
        }
    }
}
