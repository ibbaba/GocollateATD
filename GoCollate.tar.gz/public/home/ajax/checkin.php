<?php
//Manages Checking in EMployee through AJAX.
require_once(__DIR__."/../../bootstrap.php");
$session = new atd\Session();
//Check if User IsLoggedIn?
if(!atd\Auth\Auth::isUserLoggedIn())
    header("location: /../../");

header("Content-Type: application/json");

if(isset($_POST['fullname']) && isset($_POST['exp']) && isset($_POST['check'])){
    //Start New Employee Class
    $employee = new atd\Employee();
    if($employee->checkIn($_POST['fullname'], $_POST['check'], $_POST['exp'])){
        echo json_encode(["status" => "Success", "message" => "Employee Checked In."]);
    } else {
        echo json_encode(["status" => "Failed", "message" => "Employee had been checked In already."]);
    }
} else {
    echo json_encode(["status" => "Failed", "message" => "Internal Server Error."]);
}