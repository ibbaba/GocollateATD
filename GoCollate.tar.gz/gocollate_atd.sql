-- phpMyAdmin SQL Dump
-- version 4.4.3
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 16, 2016 at 08:21 AM
-- Server version: 5.6.24
-- PHP Version: 5.6.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `gocollate_atd`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE IF NOT EXISTS `admins` (
  `id` int(11) NOT NULL,
  `username` varchar(200) NOT NULL,
  `password` varchar(300) NOT NULL,
  `fullname` varchar(300) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `username`, `password`, `fullname`) VALUES
(1, 'Pythonleet', '$2y$10$zVoEv8xK.eQUKZqibVJ6tep9HVtAdWJVQkJjRr5f33uecPRds1OLu', 'Adedeji Stephen'),
(2, 'ibrahim', '$2y$10$UeESqABnJDdEQnHxrzIOLucNQZokxFZbL/u/oVIgH.GnG0uwVgiiO', 'Ibrahim');

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE IF NOT EXISTS `attendance` (
  `id` int(11) NOT NULL,
  `fullname` varchar(500) NOT NULL,
  `day` int(2) NOT NULL,
  `month` varchar(20) NOT NULL,
  `year` char(4) NOT NULL,
  `time` varchar(20) NOT NULL,
  `status` int(1) NOT NULL,
  `status_exp` varchar(20) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=132 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `attendance`
--

INSERT INTO `attendance` (`id`, `fullname`, `day`, `month`, `year`, `time`, `status`, `status_exp`) VALUES
(1, 'Adedeji Stephen', 12, 'Dec', '2016', '11:26', 1, 'present'),
(2, 'Bukola Anthony', 12, 'Dec', '2016', '11:27', 1, 'present'),
(3, 'Julia Feye', 12, 'Dec', '2016', '11:27', 0, 'absent'),
(4, 'Samuel James', 12, 'Dec', '2016', '11:33', 1, 'present'),
(5, 'Timileyin Tomi', 12, 'Dec', '2016', '11:35', 0, 'absent'),
(6, 'Grace Folashade', 12, 'Dec', '2016', '11:40', 1, 'present'),
(7, 'Adedeji Stephen', 13, 'Dec', '2016', '16:42', 1, 'present'),
(8, 'Adedeji Stephen', 0, 'Aug', '2016', '17:06', 1, 'present'),
(9, 'Adedeji Stephen', 1, 'Aug', '2016', '17:06', 1, 'present'),
(10, 'Adedeji Stephen', 2, 'Aug', '2016', '17:06', 1, 'present'),
(11, 'Adedeji Stephen', 3, 'Aug', '2016', '17:06', 1, 'present'),
(12, 'Adedeji Stephen', 4, 'Aug', '2016', '17:06', 1, 'present'),
(13, 'Adedeji Stephen', 5, 'Aug', '2016', '17:06', 1, 'present'),
(14, 'Adedeji Stephen', 6, 'Aug', '2016', '17:06', 1, 'present'),
(15, 'Adedeji Stephen', 7, 'Aug', '2016', '17:06', 1, 'present'),
(16, 'Adedeji Stephen', 8, 'Aug', '2016', '17:06', 1, 'present'),
(17, 'Adedeji Stephen', 9, 'Aug', '2016', '17:06', 1, 'present'),
(18, 'Adedeji Stephen', 10, 'Aug', '2016', '17:06', 1, 'present'),
(19, 'Adedeji Stephen', 11, 'Aug', '2016', '17:06', 1, 'present'),
(20, 'Adedeji Stephen', 12, 'Aug', '2016', '17:06', 1, 'present'),
(21, 'Adedeji Stephen', 13, 'Aug', '2016', '17:06', 1, 'present'),
(22, 'Adedeji Stephen', 14, 'Aug', '2016', '17:06', 1, 'present'),
(23, 'Adedeji Stephen', 15, 'Aug', '2016', '17:06', 1, 'present'),
(24, 'Adedeji Stephen', 16, 'Aug', '2016', '17:06', 1, 'present'),
(25, 'Adedeji Stephen', 17, 'Aug', '2016', '17:06', 1, 'present'),
(26, 'Adedeji Stephen', 18, 'Aug', '2016', '17:06', 1, 'present'),
(27, 'Adedeji Stephen', 19, 'Aug', '2016', '17:06', 1, 'present'),
(28, 'Adedeji Stephen', 20, 'Aug', '2016', '17:06', 1, 'present'),
(29, 'Adedeji Stephen', 21, 'Aug', '2016', '17:06', 1, 'present'),
(30, 'Adedeji Stephen', 22, 'Aug', '2016', '17:06', 1, 'present'),
(31, 'Adedeji Stephen', 23, 'Aug', '2016', '17:06', 1, 'present'),
(32, 'Adedeji Stephen', 24, 'Aug', '2016', '17:06', 1, 'present'),
(33, 'Adedeji Stephen', 25, 'Aug', '2016', '17:06', 1, 'present'),
(34, 'Adedeji Stephen', 26, 'Aug', '2016', '17:06', 1, 'present'),
(35, 'Adedeji Stephen', 27, 'Aug', '2016', '17:06', 1, 'present'),
(36, 'Adedeji Stephen', 28, 'Aug', '2016', '17:06', 1, 'present'),
(37, 'Adedeji Stephen', 29, 'Aug', '2016', '17:06', 1, 'present'),
(38, 'Adedeji Stephen', 0, 'Sept', '2016', '17:07', 1, 'present'),
(39, 'Adedeji Stephen', 1, 'Sept', '2016', '17:07', 1, 'present'),
(40, 'Adedeji Stephen', 2, 'Sept', '2016', '17:07', 1, 'present'),
(41, 'Adedeji Stephen', 3, 'Sept', '2016', '17:07', 1, 'present'),
(42, 'Adedeji Stephen', 4, 'Sept', '2016', '17:07', 1, 'present'),
(43, 'Adedeji Stephen', 5, 'Sept', '2016', '17:07', 1, 'present'),
(44, 'Adedeji Stephen', 6, 'Sept', '2016', '17:07', 1, 'present'),
(45, 'Adedeji Stephen', 7, 'Sept', '2016', '17:07', 1, 'present'),
(46, 'Adedeji Stephen', 8, 'Sept', '2016', '17:07', 1, 'present'),
(47, 'Adedeji Stephen', 9, 'Sept', '2016', '17:07', 1, 'present'),
(48, 'Adedeji Stephen', 10, 'Sept', '2016', '17:07', 1, 'present'),
(49, 'Adedeji Stephen', 11, 'Sept', '2016', '17:07', 1, 'present'),
(50, 'Adedeji Stephen', 12, 'Sept', '2016', '17:07', 1, 'present'),
(51, 'Adedeji Stephen', 13, 'Sept', '2016', '17:07', 1, 'present'),
(52, 'Adedeji Stephen', 14, 'Sept', '2016', '17:07', 1, 'present'),
(53, 'Adedeji Stephen', 15, 'Sept', '2016', '17:07', 1, 'present'),
(54, 'Adedeji Stephen', 16, 'Sept', '2016', '17:07', 1, 'present'),
(55, 'Adedeji Stephen', 17, 'Sept', '2016', '17:07', 1, 'present'),
(56, 'Adedeji Stephen', 18, 'Sept', '2016', '17:07', 1, 'present'),
(57, 'Adedeji Stephen', 19, 'Sept', '2016', '17:07', 1, 'present'),
(58, 'Adedeji Stephen', 20, 'Sept', '2016', '17:07', 1, 'present'),
(59, 'Adedeji Stephen', 21, 'Sept', '2016', '17:07', 1, 'present'),
(60, 'Adedeji Stephen', 22, 'Sept', '2016', '17:07', 1, 'present'),
(61, 'Adedeji Stephen', 23, 'Sept', '2016', '17:07', 1, 'present'),
(62, 'Adedeji Stephen', 24, 'Sept', '2016', '17:07', 1, 'present'),
(63, 'Adedeji Stephen', 25, 'Sept', '2016', '17:07', 1, 'present'),
(64, 'Adedeji Stephen', 26, 'Sept', '2016', '17:07', 1, 'present'),
(65, 'Adedeji Stephen', 27, 'Sept', '2016', '17:07', 1, 'present'),
(66, 'Adedeji Stephen', 28, 'Sept', '2016', '17:07', 1, 'present'),
(67, 'Adedeji Stephen', 29, 'Sept', '2016', '17:07', 1, 'present'),
(68, 'Adedeji Stephen', 0, 'Oct', '2016', '17:07', 1, 'present'),
(69, 'Adedeji Stephen', 1, 'Oct', '2016', '17:07', 1, 'present'),
(70, 'Adedeji Stephen', 2, 'Oct', '2016', '17:07', 1, 'present'),
(71, 'Adedeji Stephen', 3, 'Oct', '2016', '17:07', 1, 'present'),
(72, 'Adedeji Stephen', 4, 'Oct', '2016', '17:07', 1, 'present'),
(73, 'Adedeji Stephen', 5, 'Oct', '2016', '17:07', 1, 'present'),
(74, 'Adedeji Stephen', 6, 'Oct', '2016', '17:07', 1, 'present'),
(75, 'Adedeji Stephen', 7, 'Oct', '2016', '17:07', 1, 'present'),
(76, 'Adedeji Stephen', 8, 'Oct', '2016', '17:07', 1, 'present'),
(77, 'Adedeji Stephen', 9, 'Oct', '2016', '17:07', 1, 'present'),
(78, 'Adedeji Stephen', 10, 'Oct', '2016', '17:07', 1, 'present'),
(79, 'Adedeji Stephen', 11, 'Oct', '2016', '17:07', 1, 'present'),
(80, 'Adedeji Stephen', 12, 'Oct', '2016', '17:07', 1, 'present'),
(81, 'Adedeji Stephen', 13, 'Oct', '2016', '17:07', 1, 'present'),
(82, 'Adedeji Stephen', 14, 'Oct', '2016', '17:07', 1, 'present'),
(83, 'Adedeji Stephen', 15, 'Oct', '2016', '17:07', 1, 'present'),
(84, 'Adedeji Stephen', 16, 'Oct', '2016', '17:07', 1, 'present'),
(85, 'Adedeji Stephen', 17, 'Oct', '2016', '17:07', 1, 'present'),
(86, 'Adedeji Stephen', 18, 'Oct', '2016', '17:07', 1, 'present'),
(87, 'Adedeji Stephen', 19, 'Oct', '2016', '17:07', 1, 'present'),
(88, 'Adedeji Stephen', 20, 'Oct', '2016', '17:07', 1, 'present'),
(89, 'Adedeji Stephen', 21, 'Oct', '2016', '17:07', 1, 'present'),
(90, 'Adedeji Stephen', 22, 'Oct', '2016', '17:07', 1, 'present'),
(91, 'Adedeji Stephen', 23, 'Oct', '2016', '17:07', 1, 'present'),
(92, 'Adedeji Stephen', 24, 'Oct', '2016', '17:07', 1, 'present'),
(93, 'Adedeji Stephen', 25, 'Oct', '2016', '17:07', 1, 'present'),
(94, 'Adedeji Stephen', 26, 'Oct', '2016', '17:07', 1, 'present'),
(95, 'Adedeji Stephen', 27, 'Oct', '2016', '17:07', 1, 'present'),
(96, 'Adedeji Stephen', 28, 'Oct', '2016', '17:07', 1, 'present'),
(97, 'Adedeji Stephen', 29, 'Oct', '2016', '17:07', 1, 'present'),
(98, 'Adedeji Stephen', 0, 'Nov', '2016', '17:08', 1, 'present'),
(99, 'Adedeji Stephen', 1, 'Nov', '2016', '17:08', 1, 'present'),
(100, 'Adedeji Stephen', 2, 'Nov', '2016', '17:08', 1, 'present'),
(101, 'Adedeji Stephen', 3, 'Nov', '2016', '17:08', 1, 'present'),
(102, 'Adedeji Stephen', 4, 'Nov', '2016', '17:08', 1, 'present'),
(103, 'Adedeji Stephen', 5, 'Nov', '2016', '17:08', 1, 'present'),
(104, 'Adedeji Stephen', 6, 'Nov', '2016', '17:08', 1, 'present'),
(105, 'Adedeji Stephen', 7, 'Nov', '2016', '17:08', 1, 'present'),
(106, 'Adedeji Stephen', 8, 'Nov', '2016', '17:08', 1, 'present'),
(107, 'Adedeji Stephen', 9, 'Nov', '2016', '17:08', 1, 'present'),
(108, 'Adedeji Stephen', 10, 'Nov', '2016', '17:08', 1, 'present'),
(109, 'Adedeji Stephen', 11, 'Nov', '2016', '17:08', 1, 'present'),
(110, 'Adedeji Stephen', 12, 'Nov', '2016', '17:08', 1, 'present'),
(111, 'Adedeji Stephen', 13, 'Nov', '2016', '17:08', 1, 'present'),
(112, 'Adedeji Stephen', 14, 'Nov', '2016', '17:08', 1, 'present'),
(113, 'Adedeji Stephen', 15, 'Nov', '2016', '17:08', 1, 'present'),
(114, 'Adedeji Stephen', 16, 'Nov', '2016', '17:08', 1, 'present'),
(115, 'Adedeji Stephen', 17, 'Nov', '2016', '17:08', 1, 'present'),
(116, 'Adedeji Stephen', 18, 'Nov', '2016', '17:08', 1, 'present'),
(117, 'Adedeji Stephen', 19, 'Nov', '2016', '17:08', 1, 'present'),
(118, 'Adedeji Stephen', 20, 'Nov', '2016', '17:08', 1, 'present'),
(119, 'Adedeji Stephen', 21, 'Nov', '2016', '17:08', 1, 'present'),
(120, 'Adedeji Stephen', 22, 'Nov', '2016', '17:08', 1, 'present'),
(121, 'Adedeji Stephen', 23, 'Nov', '2016', '17:08', 1, 'present'),
(122, 'Adedeji Stephen', 24, 'Nov', '2016', '17:08', 1, 'present'),
(123, 'Adedeji Stephen', 25, 'Nov', '2016', '17:08', 1, 'present'),
(124, 'Adedeji Stephen', 26, 'Nov', '2016', '17:08', 1, 'present'),
(125, 'Adedeji Stephen', 27, 'Nov', '2016', '17:08', 1, 'present'),
(126, 'Adedeji Stephen', 28, 'Nov', '2016', '17:08', 1, 'present'),
(127, 'Adedeji Stephen', 29, 'Nov', '2016', '17:08', 1, 'present'),
(128, 'Adedeji Stephen', 14, 'Dec', '2016', '13:06', 0, 'absent'),
(129, 'Ronke Temiloluwa', 14, 'Dec', '2016', '13:06', 1, 'present'),
(130, 'Samuel James', 14, 'Dec', '2016', '13:06', 1, 'present'),
(131, 'Temitope Gloria', 14, 'Dec', '2016', '13:06', 0, 'onLeave');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE IF NOT EXISTS `employee` (
  `id` int(11) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `othername` varchar(400) NOT NULL,
  `role` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`id`, `firstname`, `othername`, `role`) VALUES
(1, 'Adedeji', 'Stephen', 'CTO'),
(2, 'Bukola', 'Anthony', 'CEO'),
(3, 'Julia', 'Feye', 'Writer'),
(4, 'Grace', 'Folashade', 'Graphics Designer'),
(5, 'Samuel', 'James', 'Cleaner'),
(6, 'Temitope', 'Gloria', 'Marketer'),
(7, 'Timileyin', 'Tomi', 'Java Programmer'),
(8, 'Ronke', 'Temiloluwa', 'Full Stack Developer');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `attendance`
--
ALTER TABLE `attendance`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `attendance`
--
ALTER TABLE `attendance`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=132;
--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
